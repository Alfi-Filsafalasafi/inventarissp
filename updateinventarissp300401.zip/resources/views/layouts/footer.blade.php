<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2023 <a href="https://alfi-filsafalasafi.github.io/My/">Alfi Filsafalasafi</a>.</strong> All rights
    reserved.
  </footer>